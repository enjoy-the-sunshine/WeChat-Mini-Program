// pages/protocol/privacy/privacy.js
Page({})
